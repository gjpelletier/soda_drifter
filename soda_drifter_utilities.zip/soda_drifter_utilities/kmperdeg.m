function [dlon, dlat] = kmperdeg(phi)

% INPUT
% phi = degrees of latitude at location of interest (-90 to 90 deg N)

% OUTPUT
% dlon = distance in km per degree of longitute at phi
% dlat = distance in km per degree of latitute at phi

% https://stackoverflow.com/questions/1253499/simple-calculations-for-working-with-lat-lon-and-km-distance

% The approximate conversions are:

% Latitude: 1 deg = 110.574 km
% Longitude: 1 deg = 111.320*cos(latitude) km
% This doesn't fully correct for the Earth's polar flattening - for that you'd probably want a more complicated formula using the WGS84 reference ellipsoid (the model used for GPS). But the error is probably negligible for your purposes.
% Caution: Be aware that latlong coordinates are expressed in degrees, while the cos function in most (all?) languages typically accepts radians, therefore a degree to radians conversion is needed.

% More accurate approximate conversions are as follows:

% - - -
% Source: http://en.wikipedia.org/wiki/Latitude

% phi 	dlat 		dlon
% 0°	110.574 km	111.320 km
% 15°	110.649 km	107.550 km
% 30°	110.852 km	96.486 km
% 45°	111.132 km	78.847 km
% 60°	111.412 km	55.800 km
% 75°	111.618 km	28.902 km
% 90°	111.694 km	0.000 km

a = 6378137.0; 	% earth radius (meters)
e2 = 0.00669437999014;	% e^2 (eccentricity squared)

% The distance in metres (correct to 0.01 metre) between latitudes phi−0.5 degrees and phi+0.5 degrees on the WGS84 spheroid is:
% dlat is distance in kilometers per degree of latitude at phi latitude of interest 
dlat = (111132.954 - 559.822 * cos(2 .* deg2rad(phi)) + 1.175 * cos(4 .* deg2rad(phi))) ./ 1000;	

% The variation of this distance with latitude (on WGS84) is shown in the table above along with the length of a degree of longitude (east–west distance):
% dlon is distance in kilometers per degree of longitude at phi latitude of interest 
dlon = ((pi() .* a .* cos(deg2rad(phi))) ./ (180 .* sqrt(1 - e2 .* sin(deg2rad(phi)).^2 ))) ./ 1000; 	

