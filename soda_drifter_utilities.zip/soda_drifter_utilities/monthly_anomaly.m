function [var_anomaly] = monthly_anomaly(var)

% function to calculate the monthly climatology of an array or vector with time in months as the last dimension
% long-term monthly average time series of same time length as input data
% written by Greg Pelletier (gjpelletier@gmail.com) 5/5/2022
%
% INPUT 
% var = 4d, 3d, 2d, or 1d array or vector of monthly data for any number of years with time as the last dimension 
%		for example: 
%			4d (lon x lat x depth x time)
%			3d (lon x lat x time)
%			2d (depth x time)
%			1d (time)
%    		(note must be repeating series of monthly data with all 12 months for each year,
%			 and time must be a multiple of 12)
%
% OUTPUT 
% var_anomaly = array of monthly anomaly compared with monthly mean climatology
%    (repeating series of monthly anomalies for all 12 months for each year)

var_ndims = ndims(var);
if ~mod(size(var,var_ndims),12)==0
	error('monthly_anomaly terminated because the time dimension is not a multiple of 12 months');
end

if var_ndims == 4
	var_rsp = reshape(var, size(var,1), size(var,2), size(var,3), 12, []); 						% reshape with time separated to month and year as separate dimensions
	var_monthly_avg = squeeze(nanmean2(var_rsp, 5));								% monthly avg across all years
	var_monthly_climatology = repmat(var_monthly_avg, 1, 1, 1, size(var_rsp,5));		% monthly climatology, repeating time series of 12 monthly means for all years
	var_anomaly = var - var_monthly_climatology;									% convert the var to the monthly anomaly
elseif var_ndims == 3
	var_rsp = reshape(var, size(var,1), size(var,2), 12, []); 						% reshape with time separated to month and year as separate dimensions
	var_monthly_avg = squeeze(nanmean2(var_rsp, 4));								% monthly avg across all years
	var_monthly_climatology = repmat(var_monthly_avg, 1, 1, size(var_rsp,4));		% monthly climatology, repeating time series of 12 monthly means for all years
	var_anomaly = var - var_monthly_climatology;									% convert the var to the monthly anomaly
elseif var_ndims == 2
	var_rsp = reshape(var, size(var,1), 12, []); 									% reshape time separated to month and year as separate dimensions
	var_monthly_avg = squeeze(nanmean2(var_rsp, 3));								% monthly avg across all years
	var_monthly_climatology = repmat(var_monthly_avg, 1, size(var_rsp,3));			% monthly climatology, repeating time series of 12 monthly means for all years
	var_anomaly = var - var_monthly_climatology;									% convert the var to the monthly anomaly
elseif var_ndims == 1
	var_rsp = reshape(var, 12, []); 												% reshape time separated to month and year as separate dimensions
	var_monthly_avg = squeeze(nanmean2(var_rsp, 2));								% monthly avg across all years
	var_monthly_climatology = repmat(var_monthly_avg, size(var_rsp,2));				% monthly climatology, repeating time series of 12 monthly means for all years
	var_anomaly = var - var_monthly_climatology;									% convert the var to the monthly anomaly
else
	var_anomaly = [];
end
