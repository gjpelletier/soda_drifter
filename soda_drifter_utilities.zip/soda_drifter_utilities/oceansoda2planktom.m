function [lon_out,lat_out,var_out] = oceansoda2planktom(lon_in,lat_in,var_in)

% function to convert 2d, 3d, or 4d arrays from OceanSODA-ETHZ to PlankTOM12 format for longitude
%
% INPUT 
% lon_in = 380x1 vector of longitudes from -179.5:1:179.5 degE
% lat_in = 180x1 vector of latitudes from -89.5:1:89.5 degN
% var_in = 4d, 3d, or 2d array data for any number of depths or months with lon and lat as first two dimensions,
% 			and optional depth and time as the last two dimension 
%		for example: 
%			4d (lon x lat x depth x time)
%			3d (lon x lat x time)
%			3d (lon x lat x depth)
%			2d (lon x lat)
%
% OUTPUT 
% lon_out = 380x1 vector of longitudes from 0.5:1:359.5 degE
% lat_out = 180x1 vector of latitudes from -89.5:1:89.5 degN
% var_out = 4d, 3d, or 2d array data in PlankTOM12 format

var_ndims = ndims(var_in);
if ~var_ndims==2 & ~var_ndims==3 & ~var_ndims==4  
	error('input array from WOA must be 2d, 3d, or 4d with lon and lat as first two dimensions');
end

NX = size(var_in,1);
NY = size(var_in,2);
if ~NX==numel(lon_in) | ~NY==numel(lat_in)  
	error('input array lon or lat do not match input vector lon or lat');
end


if var_ndims == 4

	ND = size(var_in,3);
	NT = size(var_in,4);
	lon2 = [];
	lon2 = lon_in;
	idx = find(lon2<0);
	lon2(idx) = lon2(idx) + 360;
	lon_out = [];
	lon_out(1:NX,1) = NaN;
	lon_out(1:180,1) = lon2(181:360,1);
	lon_out(181:360,1) = lon2(1:180,1);
	lat_out = lat_in;
	var_out = [];
	var_out(1:NX,1:NY,1:ND,1:NT)=NaN;
	var_out(1:180,:,:,:) = var_in(181:360,:,:,:);
	var_out(181:360,:,:,:) = var_in(1:180,:,:,:);

elseif var_ndims == 3

	ND = size(var_in,3);
	lon2 = [];
	lon2 = lon_in;
	idx = find(lon2<0);
	lon2(idx) = lon2(idx) + 360;
	lon_out = [];
	lon_out(1:NX,1) = NaN;
	lon_out(1:180,1) = lon2(181:360,1);
	lon_out(181:360,1) = lon2(1:180,1);
	lat_out = lat_in;
	var_out = [];
	var_out(1:NX,1:NY,1:ND)=NaN;
	var_out(1:180,:,:) = var_in(181:360,:,:);
	var_out(181:360,:,:) = var_in(1:180,:,:);

elseif var_ndims == 2

	lon2 = [];
	lon2 = lon_in;
	idx = find(lon2<0);
	lon2(idx) = lon2(idx) + 360;
	lon_out = [];
	lon_out(1:NX,1) = NaN;
	lon_out(1:180,1) = lon2(181:360,1);
	lon_out(181:360,1) = lon2(1:180,1);
	lat_out = lat_in;
	var_out = [];
	var_out(1:NX,1:NY)=NaN;
	var_out(1:180,:) = var_in(181:360,:);
	var_out(181:360,:) = var_in(1:180,:);

end
