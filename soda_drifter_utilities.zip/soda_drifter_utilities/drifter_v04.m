
function [drifter_lon, drifter_lat]=drifter(map_lon, map_lat, time, map_u, map_v, drifter_lon0, drifter_lat0, direction)

% - - - - -
% drifter.m
% Trajectories of passive drifter particles using Euler's method
% with the option to use either forward or reverse tracking
% - - - - -
% Copyright (c) 2022 Greg Pelletier

% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:

% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% - - - - -
%
% INPUTS:
% map_lon = vector of longitudes for map extent (degE), must be equally spaced increments of degrees
% map_lat = vector of latitudes for map extent (degN), must be equally spaced increments of degrees
% time = vector of continuous times for time series (days or datenum), may be irregularly spaced increments of time
% map_u = 3-d array (size of map_lon x map_lat x time) of east-west velocity vectors within the map extent (m/s positive east)
% map_v = 3-d array (size of map_lon x map_lat x time) of north-south velocity vectors within the map extent (m/s positive north)
% drifter_lon0 = vector of initial or final position longitudes of drifters (degE) 
% drifter_lat0 = vector of initial or final position latitudes of drifters (degN)
% direction = either 'forward' or 'reverse' for particle tracking:
%	direction = 'forward' calculates future trajectories starting at drifter_lon0 and drifter_lat0 intial drifter locations
%	direction = 'reverse' calculates past trajectories leading to the final drifter locations at drifter_lon0 and drifter_lat0
%
% OUTPUT
% drifter_lon = 2-d array (size of numel(time) x numel(drifter_lon0)) of time series of trajectoy longitudes for each drifter (degE)
% drifter_lat = 2-d array (size of numel(time) x numel(drifter_lon0)) of time series of trajectory latitudes for each drifter (degN)
% 
% - - - - -
% version history
%
% v04 fixed bug in reverse integration when drifters are stuck at the first time step gg=n_time, and corrected eqn to back up to previos positions
% v03 less verbose progress display to increase runtime speed
% v02 cleaned up depracated code
% v01 drifter.m function adapted from the integration loop in soda_drifter_v59.m

% % ----------
% % debug inputs
% % 
% map_lon = soda.mapx.lon;
% map_lat = soda.mapx.lat;
% time = soda.interp.time;
% map_u = soda.interp.u; 
% map_v = soda.interp.v;
% drifter_lon0 = soda.drifter.lon0_kk_rsp; 
% drifter_lat0 = soda.drifter.lat0_kk_rsp; 
% direction = soda.direction;
% % 
% % end debug inputs
% % ----------

n_map_lon = numel(map_lon);
n_map_lat = numel(map_lat);
n_time = numel(time);
n_drifter = numel(drifter_lon0);
timestep = diff(time) .* 86400;		% time series of Euler integration time steps (seconds)

% meshgrid x_mesh and y_mesh arrays corresponding to the input u and v arrays, used by interp2
% x_mesh is lon degE, y_mesh is lat degN
[x_mesh,y_mesh]=meshgrid(map_lon,map_lat);		

drifter_u_gg = [];
drifter_v_gg = [];
drifter_uv_gg = [];
drifter_lon = [];
drifter_lat = [];

drifter_u_gg(1:n_time,1:n_drifter) = NaN;
drifter_v_gg(1:n_time,1:n_drifter) = NaN;
drifter_uv_gg(1:n_time,1:n_drifter) = NaN;
drifter_lon(1:n_time,1:n_drifter) = NaN;
drifter_lat(1:n_time,1:n_drifter) = NaN;

% put the initial or final drifter positions in drifter_lon and drifter_lat arrays
if strcmp(direction,'forward')
	% put drifters in initial position if forward tracking
	drifter_lon(1,:) = drifter_lon0;
	drifter_lat(1,:) = drifter_lat0;
else
	% put drifters in final position of reverse tracking
	drifter_lon(n_time,:) = drifter_lon0;
	drifter_lat(n_time,:) = drifter_lat0;
end

xq = [];
yq = [];
uq = [];
vq = [];
uvq = [];
xq(1:n_drifter,1) = NaN;
yq(1:n_drifter,1) = NaN;
uq(1:n_drifter,1) = NaN;
vq(1:n_drifter,1) = NaN;
uvq(1:n_drifter,1) = NaN;

drifter_u = [];
drifter_v = [];
drifter_uv = [];
drifter_dx = [];
drifter_dy = [];
drifter_dlon = [];
drifter_dlat = [];
drifter_u(1:n_drifter,1) = NaN;
drifter_v(1:n_drifter,1) = NaN;
drifter_uv(1:n_drifter,1) = NaN;
drifter_dx(1:n_drifter,1) = NaN;
drifter_dy(1:n_drifter,1) = NaN;
drifter_dlon(1:n_drifter,1) = NaN;
drifter_dlat(1:n_drifter,1) = NaN;

ndays = time(end) - time(1) + 1;
nsteps = numel(time);
ndisp = floor(30 * round(nsteps / ndays));
% idisp = ndisp -1;
idisp = 0;

if strcmp(direction, 'forward')		% drifter tracking forward in time from specified initial position

	for gg = 1:n_time-1

	% disp(['Calculating drifter position for timestep ', num2str(gg), ' of ', num2str(n_time-1), ' ...'])
	idisp = idisp + 1;
	if idisp == ndisp
		disp(['Calculating drifter position for timestep ', num2str(gg), ' of ', num2str(n_time-1), ' ...'])
		idisp = 0;
	end

			% % use interp2 to interpolate uq and vq for all current drifter positions xq and yq
			x = x_mesh;		% degE
			y = y_mesh;		% degN
			u = squeeze(map_u(:,:,gg))';
			v = squeeze(map_v(:,:,gg))';
			xq = drifter_lon(gg,:)';	% degE
			yq = drifter_lat(gg,:)';	% degN
			uq = interp2(x,y,u,xq,yq);
			vq = interp2(x,y,v,xq,yq);
			uvq = sqrt(uq.^2 + vq.^2); 	% resultant velocity of u and v
			drifter_u_gg(gg,:) = uq';
			drifter_v_gg(gg,:) = vq';
			drifter_uv_gg(gg,:) = uvq';
			drifter_u = uq;
			drifter_v = vq;
			drifter_uv = uvq;

			% calc change dx and dy between current substep and next substep 
			% dx is change east-west position and dy is north-south position, both in Km
			drifter_dx = timestep(gg) .* drifter_u ./ 1000;			
			drifter_dy = timestep(gg) .* drifter_v ./ 1000;		

			% calc change dlon and dlat between current substep increment and next substep (dlon is change east-west position and dlat is north-south position, both in degrees)
			drifter_dlon = km2deg(drifter_dx);		
			drifter_dlat = km2deg(drifter_dy);

			for k = 1:n_drifter		% loop through drifter particles

				if gg>1 & drifter_uv(k,1) == 0
					gglast = find(drifter_uv_gg(:,k),1,'last');	% gg index of last non-zero velocity for this drifter
					if gglast == size(drifter_uv_gg,1)
						gglast = max(1,gg - 1);
					end
					ggback = gglast - floor(86400 ./ timestep(gg));			% back up to find lon lat 1 day before the last non-zero velocity
					if ggback < 1
						ggback = gglast;
					end
					drifter_lon(gg,k) = drifter_lon(ggback,k);
					drifter_lat(gg,k) = drifter_lat(ggback,k);
					x = x_mesh;						% degE
					y = y_mesh;						% degN
					u = squeeze(map_u(:,:,gg))';
					v = squeeze(map_v(:,:,gg))';
					xq2 = drifter_lon(gg,k);		% degE
					yq2 = drifter_lat(gg,k);		% degN
					uq2 = interp2(x,y,u,xq2,yq2);
					vq2 = interp2(x,y,v,xq2,yq2);
					drifter_u(k,1) = uq2;
					drifter_v(k,1) = vq2;
					drifter_uv(k,1) = sqrt(uq2.^2 + vq2.^2);
					% calc change dx and dy between current substep and next substep 
					% dx is change east-west position and dy is north-south position, both in Km
					drifter_dx(k,1) = timestep(gg) .* drifter_u(k,1) ./ 1000;			
					drifter_dy(k,1) = timestep(gg) .* drifter_v(k,1) ./ 1000;		
					% calc change dlon and dlat between current substep increment and next substep (dlon is change east-west position and dlat is north-south position, both in degrees)
					drifter_dlon(k,1) = km2deg(drifter_dx(k,1));		
					drifter_dlat(k,1) = km2deg(drifter_dy(k,1));
				end

				% find new postion of drifter at the end of this step
				drifter_lon(gg+1,k) = drifter_lon(gg,k) + drifter_dlon(k,1);
				drifter_lat(gg+1,k) = drifter_lat(gg,k) + drifter_dlat(k,1);

			end		% for k
	end				% for gg

else 	% reverse drifter tracking backward in time from specified final position

	map_u = -map_u;
	map_v = -map_v;

	for gg = n_time:-1:2

	% disp(['Calculating drifter position for timestep ', num2str(gg-1), ' of ', num2str(n_time-1), ' ...'])
	idisp = idisp + 1;
	if idisp == ndisp
		disp(['Calculating drifter position for timestep ', num2str(gg-1), ' of ', num2str(n_time-1), ' ...'])
		idisp = 0;
	end

			% % use interp2 to interpolate uq and vq for all current drifter positions xq and yq
			x = x_mesh;		% degE
			y = y_mesh;		% degN
			u = squeeze(map_u(:,:,gg))';
			v = squeeze(map_v(:,:,gg))';
			xq = drifter_lon(gg,:)';	% degE
			yq = drifter_lat(gg,:)';	% degN
			uq = interp2(x,y,u,xq,yq);
			vq = interp2(x,y,v,xq,yq);
			uvq = sqrt(uq.^2 + vq.^2); 	% resultant velocity of u and v
			drifter_u_gg(gg,:) = uq';
			drifter_v_gg(gg,:) = vq';
			drifter_uv_gg(gg,:) = uvq';
			drifter_u = uq;
			drifter_v = vq;
			drifter_uv = uvq;

			% calc change dx and dy between current substep and next substep 
			% dx is change east-west position and dy is north-south position, both in Km
			drifter_dx = timestep(gg-1) .* drifter_u ./ 1000;			
			drifter_dy = timestep(gg-1) .* drifter_v ./ 1000;		

			% calc change dlon and dlat between current substep increment and next substep (dlon is change east-west position and dlat is north-south position, both in degrees)
			drifter_dlon = km2deg(drifter_dx);		
			drifter_dlat = km2deg(drifter_dy);

			for k = 1:n_drifter		% loop through drifter particles

				if gg>1 & drifter_uv(k,1) == 0
					gglast = find(drifter_uv_gg(:,k),1,'last');	% gg index of last non-zero velocity for this drifter
					if gglast == size(drifter_uv_gg,1)
						gglast = max(1,gg - 1);
					end

					% v04
					% ggback = gglast - floor(86400 ./ timestep(gg));			% back up to find lon lat 1 day before the last non-zero velocity
					% if ggback < 1
						% ggback = gglast;
					% end
					if gg == n_time
						ggback = gglast + floor(86400 ./ timestep(n_time-1));			% back up to find lon lat 1 day before the last non-zero velocity
					else
						ggback = gglast + floor(86400 ./ timestep(gg));			% back up to find lon lat 1 day before the last non-zero velocity
					end
					if ggback > n_time
						ggback = gglast;
					end

					drifter_lon(gg,k) = drifter_lon(ggback,k);
					drifter_lat(gg,k) = drifter_lat(ggback,k);
					x = x_mesh;						% degE
					y = y_mesh;						% degN
					u = squeeze(map_u(:,:,gg))';
					v = squeeze(map_v(:,:,gg))';
					xq2 = drifter_lon(gg,k);		% degE
					yq2 = drifter_lat(gg,k);		% degN
					uq2 = interp2(x,y,u,xq2,yq2);
					vq2 = interp2(x,y,v,xq2,yq2);
					drifter_u(k,1) = uq2;
					drifter_v(k,1) = vq2;
					drifter_uv(k,1) = sqrt(uq2.^2 + vq2.^2);
					% calc change dx and dy between current substep and next substep 
					% dx is change east-west position and dy is north-south position, both in Km

					% v04
					% drifter_dx(k,1) = timestep(gg) .* drifter_u(k,1) ./ 1000;			
					% drifter_dy(k,1) = timestep(gg) .* drifter_v(k,1) ./ 1000;		
					if gg == n_time
						drifter_dx(k,1) = timestep(n_time-1) .* drifter_u(k,1) ./ 1000;			
						drifter_dy(k,1) = timestep(n_time-1) .* drifter_v(k,1) ./ 1000;		
					else
						drifter_dx(k,1) = timestep(gg) .* drifter_u(k,1) ./ 1000;			
						drifter_dy(k,1) = timestep(gg) .* drifter_v(k,1) ./ 1000;		
					end

					% calc change dlon and dlat between current substep increment and next substep (dlon is change east-west position and dlat is north-south position, both in degrees)
					drifter_dlon(k,1) = km2deg(drifter_dx(k,1));		
					drifter_dlat(k,1) = km2deg(drifter_dy(k,1));
				end

				% find new postion of drifter at the end of this step
				drifter_lon(gg-1,k) = drifter_lon(gg,k) + drifter_dlon(k,1);
				drifter_lat(gg-1,k) = drifter_lat(gg,k) + drifter_dlat(k,1);

			end		% k loop


	end				% gg loop

	% % put the u and v velocity vectors back into the correct sign after calculationg the reverse drifter tracking
	map_u = -map_u;
	map_v = -map_v;

end



