
% function [] = soda_drifter_animation(quiver_lon, quiver_lat, quiver_u, quiver_v, ...
function soda_drifter_animation(quiver_lon, quiver_lat, quiver_u, quiver_v, ...
								quiver_scale, quiver_color, quiver_width, plot_title, quiver_show, ...
								drifter_lon, drifter_lat, drifter_show, ...
								drifter_facecolor, drifter_edgecolor, drifter_size, drifter_integrate, ...
								overlay, overlay_name, ...
								overlay_lon, overlay_lat, overlay_data, ...
								overlay_min, overlay_max, overlay_cm, overlay_pivot, overlay_opacity, ...
								crop_lon, crop_lat, crop_name, ...
								frame_time, gifname, gifdelay, gifpause)

% - - - - -
% soda_drifter_animation.m
% Make animated GIF of trajectories of passive drifter particles for use with soda_drifter.m
% - - - - -
% Copyright (c) 2022 Greg Pelletier

% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:

% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% - - - - -

% version history

% v05 flip jet2 in southern hemisphere
% v04 extended lon ticks to southern hemisphere
% v01 drifter_animation.m function adapted from the animation loop in soda_drifter_v59.m

% - - - - -

% quiver_lon = soda.map1.lon-360;		% convert degE to degW
% quiver_lat = soda.map1.lat;			% degN
% quiver_u = soda.drifter.weekly_u;
% quiver_v = soda.drifter.weekly_v;

% quiver_scale = soda.quiverscale;
% quiver_color = soda.quivercolor;
% quiver_width = soda.quiverwidth;
% quiver_label = soda.depthlabel;
% quiver_show = soda.overlay_quiver;

% drifter_lon = soda.drifter.weekly_lon-360;		% convert degE to degW
% drifter_lat = soda.drifter.weekly_lat;			% degN
% drifter_show = soda.overlaydrifter

% drifter_facecolor = soda.markerfacecolor;
% drifter_edgecolor = soda.markeredgecolor;
% drifter_size = soda.markersize;
% drifter_integrate = soda.integrate;

% overlay = soda.overlay;
% overlay_name = soda.overlay_name;

% overlay_lon = soda.overlay_lon;					% already degW
% overlay_lat = soda.overlay_lat;					% degN
% overlay_data = soda.drifter.weekly_overlay_data;

% overlay_min = soda.overlay_min;
% overlay_max = soda.overlay_max;
% overlay_cm = soda.overlay_cm;
% overlay_pivot = soda.overlay_pivot;
% overlay_opacity = soda.overlay_opacity;

% crop_lon = soda.maplon;							% already degW
% crop_lat = soda.maplat;							% degN
% crop_name = soda.whichmap;

% frame_time = soda.drifter.weekly_time;
% gifname = soda.gifname;
% gifdelay = soda.gifdelay;
% gifpause = soda.gifpause;

% year, month, and day of weekly time series
frame_datenum = double(frame_time + datenum(datetime(1980,1,1,0,0,0)));
frame_datetime = datetime(frame_datenum,'ConvertFrom','datenum');
[frame_year,frame_month,frame_day] = ymd(frame_datetime);

n_map_lon = numel(quiver_lon);
n_map_lat = numel(quiver_lat);
n_time = numel(frame_time);
n_drift = size(drifter_lon,2);

% meshgrid x_mesh and y_mesh arrays corresponding to the input u and v arrays, used to map quiver arrows
% x_mesh is lon degW, y_mesh is lat degN
[quiver_x_mesh,quiver_y_mesh]=meshgrid(quiver_lon,quiver_lat);		

% ----------
% monthly frames

% iskip = (soda.pickstartyear - soda.startyear) * 12 + soda.pickstartmonth - 1;
% soda.pickyear = soda.pickstartyear;
clear colormap
if drifter_show
	ck=colormap(jet2(n_drift));
	if crop_lat(2) <= 0
		ck = flipud(ck);
	end
end
for i = 1:n_time	% loop thru months
disp(['Making animation of drifters for frame ', num2str(i), ' of ', num2str(n_time), ' ...'])
	figure(1)
	hFig=gcf;
	clf(hFig);
	% 
	hold on
	%
	% v51
	m_proj('mercator','lat',crop_lat,'long',crop_lon);
	%
	% overlay omara satdep or other data
	if ~strcmp(overlay,'none')
		clear X Y Z
		X = overlay_lon;
		Y = overlay_lat;
		Z = squeeze(overlay_data(:,:,i))';
		[C,h] = m_contourf(X,Y,Z,256);
		set(h,'LineColor','none')
		caxis([overlay_min overlay_max]);
		h=colorbar;
		h.Label.String=overlay_name;
		% v49
		if strcmp(overlay_cm,'balance') | strcmp(overlay_cm,'-balance') | ...
				strcmp(overlay_cm,'delta') | strcmp(overlay_cm,'-delta') | ...
				strcmp(overlay_cm,'curl') | strcmp(overlay_cm,'-curl')
			if ~isnan(overlay_pivot)
				cmocean2(overlay_cm,'pivot',overlay_pivot,'opacity',overlay_opacity);
			else
				cmocean2(overlay_cm,'opacity',overlay_opacity);
			end
		else 
			cmocean2(overlay_cm,'opacity',overlay_opacity);
		end
	end
	%
	m_gshhs_i('patch',[.9 .9 .9],'edgecolor',[.9 .9 .9]);		% intermediate res coast
	if quiver_show
	% overlay current vector quiver arrows
		clear x y u v scale
		x = quiver_x_mesh;
		y = quiver_y_mesh;
		u = squeeze(quiver_u(:,:,i))';
		v = squeeze(quiver_v(:,:,i))';
		% m_quiver(x,y,u,v,scale,'color','k','linewidth',.5);
		m_quiver(x,y,u,v,quiver_scale,'color',quiver_color,'linewidth',quiver_width);
	end
	% overlay drifters
	if drifter_show
		if strcmp(drifter_facecolor,'jet')
			for k = 1:n_drift
				% v50
				if strcmp(drifter_edgecolor,'jet')
					m_plot(squeeze(drifter_lon(i,k,:)), squeeze(drifter_lat(i,k,:)),'o','linewidth',1,'color',ck(k,:),'markerfacecolor',ck(k,:),'MarkerSize',drifter_size)
				else
					m_plot(squeeze(drifter_lon(i,k,:)), squeeze(drifter_lat(i,k,:)),'o','linewidth',1,'color',drifter_edgecolor,'markerfacecolor',ck(k,:),'MarkerSize',drifter_size)
				end
			end
		else
			for k = 1:n_drift
				% v50
				if strcmp(drifter_edgecolor,'jet')
					m_plot(squeeze(drifter_lon(i,k,:)), squeeze(drifter_lat(i,k,:)),'o','linewidth',1,'color',ck(k,:),'markerfacecolor',drifter_facecolor,'MarkerSize',drifter_size)
				else
					m_plot(squeeze(drifter_lon(i,k,:)), squeeze(drifter_lat(i,k,:)),'o','linewidth',1,'color',drifter_edgecolor,'markerfacecolor',drifter_facecolor,'MarkerSize',drifter_size)
				end
			end
		end
	end
	% title(['Drifters at depth of_ ',quiver_label,', ',num2str(frame_year(i,1)),'-',num2str(frame_month(i,1),'%02.f')])
	title([plot_title,',_ ',num2str(frame_year(i,1)),'-',num2str(frame_month(i,1),'%02.f')])
	m_grid('box','off','linestyle','none','XaxisLocation','bottom','YaxisLocation','left','xtick',([-240 -230 -220 -210 -200 -190 -180 -170 -160 -150 -140 -130 -120 -110 -100 -90 -80 -70 -60]),'ytick',([-65 -60 -50 -40 -30 -20 -10 0 10 20 30 40 50 60 65]),'FontSize',8);	% N Pacific
	%
	set(gca,'TickDir','out');	% the only other option is 'in'
	hold off
	%
	% if soda.savepng
		% % print uses figure 'PaperPosition' for the size
		% if strcmp(soda.whichmap,'PacificN') 
			% set(gcf, 'PaperPosition', [0 0 10 6])    % N Pacific
		% elseif strcmp(soda.whichmap,'PacificNE') 
			% set(gcf, 'PaperPosition', [0 0 7 7])    % NE Pacific
			% elseif strcmp(soda.whichmap,'PacificNE2') 
				% set(gcf, 'PaperPosition', [0 0 8 6])    % NE Pacific region of Dick's 135W line
			% elseif strcmp(soda.whichmap,'PacificNW') 
				% set(gcf, 'PaperPosition', [0 0 8 6])    % NW Pacific region of Japanese pteropod stations
		% end
		% % print(gcf, [pwd '/ani/Drifter_',soda.whichmap,'_',soda.whichdrifters,'_',num2str(soda.pickstartyear),'_',num2str(soda.pickendyear),'_',num2str(i,'%02.f'),'.png'], '-dpng', '-r300' );   %save file as PNG w/ 300dpi
		% print(gcf, [pwd '/ani/Drifter_',soda.whichmap,'_',soda.whichdrifters,'_',num2str(soda.pickstartyear),'_',num2str(soda.pickendyear),'_',soda.overlay,'_mov',num2str(soda.movmean_months),'mo_',soda.ver,'_',num2str(i,'%02.f'),'.png'], '-dpng', '-r300' );   %save file as PNG w/ 300dpi
	% end
	% write animated gif
	% set(0,'DefaultFigureColor',[1 1 1])
	set(gcf,'color','w');
		% gif/export_fig uses figure 'Position' for the size
		if strcmp(crop_name,'PacificN') 
			set(gcf,'Position',[100 120 960 540]);	% 16:9 ratio for wide figs
		else 
			% set(gcf,'Position',[100 120 560 420]);	% 4:3 ratio for normal figs
			set(gcf,'Position',[100 120 640 480]);	% 4:3 ratio for normal figs
		end
	if i == 1
		gif(gifname,'DelayTime',gifdelay*gifpause,'resolution',300,'overwrite',true,'nodither')
	elseif i == n_time
		gif('DelayTime',gifdelay*gifpause)
	else
		gif('DelayTime',gifdelay)
	end
end 	% loop through months
clear x y u v scale

