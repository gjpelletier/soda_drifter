
function [drifter_overlay]=interp2_drifter_overlay(drifter_lon, drifter_lat, overlay_lon, overlay_lat, overlay_data)

% - - - - -
% interp2_drifter_overlay.m
% Interpolate overlay data from a comparison map layer (e.g. pH or omega) 
% using interp2 with the drifter trajectories lon and lat vs time as the query xq, yq, to find zq
% from the overlay lon, lat, and time series of data values as the x, y, and z
% - - - - -
% Copyright (c) 2022 Greg Pelletier

% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:

% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% - - - - -
%
% INPUTS:
% drifter_lon = 2-d array (size of number of times x number of drifter particles) of time series of trajectoy longitudes for each drifter (degE)
% drifter_lat = 2-d array (size of number of times x number of drifter particles) of time series of trajectory latitudes for each drifter (degN)
% overlay_lon = vector of longitudes for map extent (degE) of overlay data, must be equally spaced increments of degrees
% overlay_lat = vector of latitudes for map extent (degN) of overlay data, must be equally spaced increments of degrees
% overlay_data = 3-d array (size of map_lon x map_lat x time) of overlay data values within the map extent (same units as overlay data values)

% OUTPUT:
% drifter_overlay = 2-d array (size of number of times x number of drifter particles) of time series of overlay data for each drifter (degE)

% % debug inputs
% drifter_lon = soda.drifter.lon_rsp;
% drifter_lat = soda.drifter.lat_rsp;
% overlay_lon = soda.overlay_lon+360; 	% convert from -degW to degE
% overlay_lat = soda.overlay_lat;
% overlay_data = soda.interp.overlay_data;

% - - - - -

n_overlay_lon = numel(overlay_lon);
n_overlay_lat = numel(overlay_lat);
n_time = size(overlay_data,3);
if ~(size(overlay_data,3)== size(drifter_lon,1) & size(drifter_lat,1)== size(drifter_lon,1))
	error('Program terminated because time index is not the same in drifter_lon, drifter_lat, and overlay_data');
end
n_drifter = size(drifter_lon,2);
if ~(size(drifter_lat,2)== size(drifter_lon,2))
	error('Program terminated because number of drifter particles in drifter_lon and drifter_lat are not equal');
end

% meshgrid x_mesh and y_mesh arrays corresponding to the input u and v arrays, used by interp2
% x_mesh is lon degE, y_mesh is lat degN
[x_mesh,y_mesh]=meshgrid(overlay_lon,overlay_lat);		

drifter_overlay = [];
drifter_overlay(1:n_time,1:n_drifter) = NaN;

xq = [];
yq = [];
zq = [];
xq(1:n_time,1) = NaN;
yq(1:n_time,1) = NaN;
zq(1:n_time,1) = NaN;

for i = 1:n_time
	% % use interp2 to interpolate uq and vq for all current drifter positions xq and yq
	x = x_mesh;		% degE
	y = y_mesh;		% degN
	z = squeeze(overlay_data(:,:,i))';
	xq = drifter_lon(i,:)';	% degE
	yq = drifter_lat(i,:)';	% degN
	zq = interp2(x,y,z,xq,yq);
	drifter_overlay(i,:) = zq';
end				% i loop



